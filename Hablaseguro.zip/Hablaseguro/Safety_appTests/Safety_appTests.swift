//
//  Safety_appTests.swift
//  Safety_appTests
//
//  Created by sharath rana on 5/1/25.
//

import Testing
@testable import Safety_app

struct Safety_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
