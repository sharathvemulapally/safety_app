import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var path = NavigationPath()
    @State private var audioPlayer: AVAudioPlayer?

    var body: some View {
        NavigationStack(path: $path) {
            HomeView(path: $path, playAudio: playAudio)
                .navigationDestination(for: Screen.self) { screen in
                    switch screen {
                    case .topics:
                        TopicsView(path: $path, playAudio: playAudio)
                    case .subtopics(let subtopics, let title):
                        SubtopicsView(path: $path, subtopics: subtopics, title: title, playAudio: playAudio)
                    case .recommendations(let topic):
                        RecommendationsView(path: $path, topic: topic, playAudio: playAudio)
                    }
                }
        }
    }

    func playAudio(_ phrase: String) {
        
        let audioFileName = phrase.lowercased()
                .replacingOccurrences(of: "'", with: "")
                .replacingOccurrences(of: "’", with: "")
                .replacingOccurrences(of: ",", with: "")
                .replacingOccurrences(of: ".", with: "")
                .replacingOccurrences(of: "!", with: "")
                .replacingOccurrences(of: "?", with: "")
                .replacingOccurrences(of: " ", with: "_")
                .replacingOccurrences(of: "/", with: "_")
                .replacingOccurrences(of: ";", with: "")
        
        guard let asset = NSDataAsset(name: audioFileName) else {
            print("Audio not found in Assets.xcassets")
            return
        }
        do {
            audioPlayer = try AVAudioPlayer(data: asset.data, fileTypeHint: AVFileType.m4a.rawValue)
            audioPlayer?.play()
        } catch {
            print("Audio playback error: \(error.localizedDescription)")
        }
    }
}

enum Screen: Hashable {
    case topics
    case subtopics(subtopics: [String], title: String)
    case recommendations(topic: String)
}

struct HeaderView: View {
    @Binding var path: NavigationPath
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            if let uiImage = UIImage(named: "header") {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 80)
            } else {
                Color.gray
                    .frame(height: 80)
                    .overlay(Text("Header Image Not Found").foregroundColor(.white))
            }
            
            VStack(alignment: .leading) {
                
                Button(action: { path = NavigationPath() }) {
                    Image(systemName: "house.fill")
                        .foregroundColor(.blue)
                        .padding(12)
                }
                .offset(x: 2, y: 65)
            }
        }
        .onAppear {
            print("Attempting to load header image")
            if UIImage(named: "header") == nil {
                print("Header image not found in bundle")
            }
        }
    }
}

struct HomeView: View {
    @Binding var path: NavigationPath
    var playAudio: (String) -> Void
    
    var body: some View {
        VStack {
            HeaderView(path: $path)
            
            Spacer()
            
            VStack(spacing: 20) {
                Button(action: { playAudio("emergency_stop") }) {
                    Text("EMERGENCY STOP")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .frame(width: 250)
                
                Button("Topics") { path.append(Screen.topics) }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                    .frame(width: 250)
            }
            .frame(maxWidth: .infinity)
            
            Spacer()
            
            if let uiImage = UIImage(named: "footer") {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 80)
            } else {
                Color.gray
                    .frame(height: 80)
                    .overlay(Text("footer Image Not Found").foregroundColor(.white))
            }
        }
        .padding()
    }
}

struct TopicsView: View {
    @Binding var path: NavigationPath
    var playAudio: (String) -> Void
    let topics = ["General Safety Orientation","PPE","Fall Protection","Scaffolding Safety","Ladder Safety","Trenching/Excavation","General Jobsite Safety","Restricted Access","Environmental and Weather Conditions","Fire Safety"]
    var body: some View {
        VStack {
            HeaderView(path: $path)
            Text("Select a Topic").font(.title2).padding()
            List(topics, id: \ .self) { topic in
                Button(topic) {
                    if topic == "PPE" {
                        path.append(Screen.subtopics(subtopics: ppeSubtopics, title: "Select a PPE Subtopic"))
                    } else if topic == "Fall Protection" {
                        path.append(Screen.subtopics(subtopics: fallProtectionSubtopics, title: "Select a Fall Protection Subtopic"))
                    }
                    else if topic == "General Jobsite Safety" {
                        path.append(Screen.subtopics(subtopics: generalJobSiteSafetySubtopics, title: "Select a General Jobsite Safety Subtopic"))
                    }
                    else {
                        path.append(Screen.recommendations(topic: topic))
                    }
                }
            }
            Button("Back") { path.removeLast() }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
          
        }.padding()
    }
}

let ppeSubtopics = ["General PPE Requirements", "Head Protection", "Eye and Face Protection", "Foot Protection", "High-Visibility Clothing", "Hand Protection", "Hearing Protection"]
let fallProtectionSubtopics = ["Harness and Lifeline", "Fall Protection Requirements", "Inspection and Compliance"]
let generalJobSiteSafetySubtopics = [ "Immediate Safety Concerns", "Equipment Safety","Site Maintenance and Cleanliness", "Specific Safety Procedures", "Material Storage"]


struct SubtopicsView: View {
    @Binding var path: NavigationPath
    let subtopics: [String]
    let title: String
    var playAudio: (String) -> Void
    var body: some View {
        VStack {
            HeaderView(path: $path)
            Text(title).font(.title2).padding()
            List(subtopics, id: \ .self) { subtopic in
                Button(subtopic) { path.append(Screen.recommendations(topic: subtopic)) }
            }
            Button("Back") { path.removeLast() }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
        }.padding()
    }
}

struct RecommendationsView: View {
    @Binding var path: NavigationPath
    let topic: String
    var playAudio: (String) -> Void
    var recommendations: [String] { recommendationsMap[topic] ?? [] }
    var body: some View {
        VStack {
            HeaderView(path: $path)
            Text("Recommendations for \(topic)").font(.title2).padding()
            ScrollView {
                ForEach(recommendations, id: \ .self) { rec in
                    Button(action: { playAudio(rec) }) {
                        Text(rec)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(12)
                            .shadow(radius: 2)
                    }.padding(.vertical, 4)
                }
            }
            Button("Back") { path.removeLast() }
                .frame(maxWidth: .infinity)
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)

        }.padding()
    }
}

let recommendationsMap: [String: [String]] = [
    "General Safety Orientation": [
        "Have you been through orientation?",
        "Don’t miss any safety meetings.",
        "Please read our safety violation fines.",
        "Who do you work for?",
        "Who is in charge/Who is the boss/Who do you report to?"
    ],
    "PPE": [
        "General PPE Requirements",
        "Head Protection",
        "Eye and Face Protection",
        "Foot Protection",
        "High-Visibility Clothing",
        "Hand Protection",
        "Hearing Protection"
    ],
    "General PPE Requirements": [
        "PPE is required at all times.",
        "We will fine you if you don’t wear your PPE.",
        "Please use proper PPE."
    ],
    "Head Protection": [
        "Put on your hard hat.",
        "Where is your hard hat?",
        "You cannot wear a baseball cap or sweatshirt hood under your hard hat.",
        "The brim of your hard hat needs to be forward."
    ],
    "Eye and Face Protection": [
        "Face shield is required for this task.",
        "Put on your safety glasses.",
        "Where are your safety glasses?",
        "You cannot wear sunglasses in the building.",
        "Your safety glasses do not meet OSHA or ANSI requirements."
    ],
    "Foot Protection": [
        "Put on your work boots.",
        "You are working in concrete; put the proper boots on."
    ],
    "High-Visibility Clothing": [
        "Put on your reflective vest or high visibility clothing.",
        "Where is your reflective vest or high visibility clothing?",
        "You need a high visibility vest or clothing if you are working in or near vehicle traffic.",
        "Uncover your high visibility shirt."
    ],
    "Hand Protection": [
        "Put on your gloves.",
        "Where are your gloves?",
        "Those are the wrong gloves for the task."
    ],
    "Hearing Protection": [
        "Wear your ear protection.",
        "Where is your ear protection?"
    ],
    "Fall Protection": [
        "Harness and Lifeline",
        "Fall Protection Requirements",
        "Inspection and Compliance"
    ],
    "Harness and Lifeline": [
        "Your harness is not being worn correctly.",
        "The leg straps of your harness must be connected and secured.",
        "Take the slack out of your rope slide up your rope grab.",
        "Adjust the lifeline.",
        "Adjust the slack on your lifeline or relocate the anchor point; you are exposed to a swing hazard.",
        "Your D ring needs to be between your shoulder blades.",
        "The energy absorber’s cover is missing."
    ],
    "Fall Protection Requirements": [
        "Fall protection is required above six feet.",
        "You need fall protection when working at or above 6 feet No exceptions.",
        "You need guard rails around this floor hole and wall opening.",
        "You cannot walk the top plate of walls."
    ],
    "Inspection and Compliance": [
        "Have you inspected your safety harness, self retractable lifeline SRL or Yoyo, and/or lanyard, and other fall protection equipment being used?",
        "How many nails did you use to install the hinge anchor?",
        "Did you follow the manufacturer's instructions?",
        "Have you inspected your personal fall arrest system?"
    ],
    "Scaffolding Safety": [
        "You need guard rails on your scaffolding.",
        "You can’t climb the scaffolding; you need a ladder.",
        "The scaffolding must be inspected and tagged before you can use it.",
        "Your scaffolding is not safe, stop work and correct.",
        "You have damaged scaffold components.",
        "The scaffold boards need to meet OSHA requirements.",
        "The scaffold needs to be fully planked with no openings.",
        "You need a top and mid rail. The crossbars can be used for one of them.",
        "On mobile scaffold lock the wheels, you cannot move the scaffold with somebody on it.",
        "You cannot throw materials up or down.",
        "The scaffold is missing locking pins.",
        "Scaffold components need to be from the same manufacturer.",
        "If materials are on the scaffold, it is a working scaffold and needs to comply with all scaffold and fall protection measures.",
        "Did you follow the manufacturer's instructions?"
    ],
    "Ladder Safety": [
        "Your ladder needs to extend 3 feet above your landing.",
        "Your ladder needs to be tied off at the top and bottom.",
        "The top of the straight ladder needs to be secured.",
        "Your ladder is damaged, take it off the site.",
        "You cannot throw materials up or down."
    ],
    "Trenching/Excavation": [
        "Get out of the ditch/hole.",
        "The excavation is over 5 ft. deep get out, it needs to be sloped or you need a trench box.",
        "You need a ladder in the excavation."
    ],
    "Immediate Safety Concerns": [
        "Stop! That isn't safe.",
        "Get out of the ditch/hole.",
        "Dont walk under the load of the crane.",
        "Overhead power lines Stay at least 10 feet away.",
        "Only authorized and trained workers can enter confined spaces and a permit is needed.",
        "Get down, you are working at or above 6 feet without fall protection."
    ],
    "Equipment Safety": [
        "Have you inspected the scissor lift or boom lift?",
        "Have you been trained to operate this piece of equipment?",
        "Do you have the proper rigging to move these materials with the crane?",
        "Do you have a lift plan?",
        "Did you follow the manufacturer's instructions?",
        "All mobile equipment needs working backup alarms."
    ],
    "Tool Safety": [
        "Did you follow the manufacturer's instructions?",
        "Your extension cord is damaged and needs to be taken off site.",
        "Protect that extension cord from damage.",
        "Have you inspected your hand and power tools this month?",
        "This tool is damaged. Take it off site."
    ],
    "Site Maintenance and Cleanliness": [
        "Please clean your space.",
        "We need to throw away the trash into provided containers.",
        "Please pick up your trash and dispose of it in the provided containers.",
        "Ensure your boots are clean of mud prior to entering the building.",
        "Do not dump paint or other chemicals in the storm drain."
    ],
    "Specific Safety Procedures": [
        "Water needs to be used while cutting and/or grinding concrete or masonry to reduce silica dust.",
        "You need to use dust control attachments designed for the tool.",
        "Use Hepa Vacuum system when sanding drywall to control the silica dust."
    ],
    "Material Storage": [
        "Materials are leaning and will fall over, stack them properly or move them.",
        "Materials and tools are blocking areas where work needs to be completed, please move them ASAP."
    ],
    "Restricted Access": ["The barricade needs a tag, which should include company name, contact person, and phone number.",
                          "Only the electricians can access this room.",
                          "Only the framers and roofers can go on the roof.",
                          "This is a confined space; you need a permit and training."],
    "Environmental and Weather Conditions": ["No work allowed if it’s lightning.",
                                             "No work due to rain.",
                                             "Do you have water? Drink it frequently.",
                                             "Do not touch or move the heater, only authorized personnel can do it.",
                                             "No scaffold work or work on roofs due to high winds.",
                                             "Take frequent breaks in the shade during this high heat.",
                                             "There is not enough light in the area to do work, get additional lights"],
    "Fire Safety": ["No fires or burning are allowed.",
                    "If you are welding, burning, or using an open flame, you need a hot work permit and fire extinguisher."]
]
