//
//  Safety_appApp.swift
//  Safety_app
//
//  Created by sharath rana on 5/1/25.
//

import SwiftUI

@main
struct Safety_appApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
