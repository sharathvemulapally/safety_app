package com.example.project

import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.*
import com.example.project.ui.theme.PROJECTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PROJECTTheme {
                AppNavigation(::playSpanishAudio)
            }
        }
    }

    fun playSpanishAudio(text: String, context: android.content.Context) {
        // Convert text to a valid resource name: lowercase, replace spaces with underscores
        val audioFileName = text.lowercase()
            .replace("'", "")
            .replace("’", "")
            .replace(",", "")
            .replace(".", "")
            .replace("!", "")
            .replace("?", "")
            .replace(" ", "_")
            .replace("/", "_")
            .replace(";", "")

        try {
            // Get resource ID from raw folder
            val resId = context.resources.getIdentifier(audioFileName, "raw", context.packageName)
            if (resId == 0) {
                Toast.makeText(context, "Spanish audio not found for: $text", Toast.LENGTH_SHORT).show()
                return
            }

            // Create and play MediaPlayer
            val mediaPlayer = MediaPlayer.create(context, resId)
            mediaPlayer?.setOnCompletionListener { mp ->
                mp.release()
            }
            mediaPlayer?.start() ?: Toast.makeText(context, "Error playing audio", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "Error playing Spanish audio: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object Topics : Screen("topics")
    object PPE : Screen("ppe")
    object FallProtection : Screen("fall_protection")
    object TrenchingExcavation : Screen("trenching_excavation")
    object GeneralJobsiteSafety : Screen("general_jobsite_safety")
    object RestrictedAccess : Screen("restricted_access")
    object EnvironmentalConditions : Screen("environmental_conditions")
    object FireSafety : Screen("fire_safety")
    object Recommendations : Screen("recommendations/{topic}") {
        fun createRoute(topic: String) = "recommendations/$topic"
    }
}

@Composable
fun AppNavigation(playSpanishAudio: (String, android.content.Context) -> Unit) {
    val navController = rememberNavController()
    NavHost(navController, startDestination = Screen.Home.route) {
        composable(Screen.Home.route) { HomeScreen(navController, playSpanishAudio) }
        composable(Screen.Topics.route) { TopicsScreen(navController, playSpanishAudio) }
        composable(Screen.PPE.route) { PPESubtopicsScreen(navController, playSpanishAudio) }
        composable(Screen.FallProtection.route) { FallProtectionSubtopicsScreen(navController, playSpanishAudio) }
        composable(Screen.TrenchingExcavation.route) { TrenchingExcavationScreen(navController, playSpanishAudio) }
        composable(Screen.GeneralJobsiteSafety.route) { GeneralJobsiteSafetyScreen(navController, playSpanishAudio) }
        composable(Screen.RestrictedAccess.route) { RestrictedAccessScreen(navController, playSpanishAudio) }
        composable(Screen.EnvironmentalConditions.route) { EnvironmentalConditionsScreen(navController, playSpanishAudio) }
        composable(Screen.FireSafety.route) { FireSafetyScreen(navController, playSpanishAudio) }
        composable(Screen.Recommendations.route) { backStackEntry ->
            val topic = backStackEntry.arguments?.getString("topic") ?: "Unknown Topic"
            RecommendationsScreen(navController, topic, playSpanishAudio)
        }
    }
}

@Composable
fun ScreenContentWithHeader(
    navController: NavController,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = R.drawable.header),
                contentDescription = "Header Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(64.dp)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 8.dp),
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.CenterHorizontally,
                content = content
            )
        }
        HomeButton(navController = navController, modifier = Modifier.align(Alignment.TopStart))
    }
}

@Composable
fun ScreenContentWithFooter(
    navController: NavController,
    content: @Composable ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        Image(
            painter = painterResource(id = R.drawable.jsi),
            contentDescription = "Footer Image",
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .height(100.dp)
                .padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun HomeButton(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    IconButton(
        onClick = { navController.navigate(Screen.Home.route) },
        modifier = modifier
            .padding(horizontal = 1.dp, vertical = 50.dp)
            .size(40.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Home,
            contentDescription = "Home",
            tint = Color.Blue
        )
    }
}

@Composable
fun HomeScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val context = LocalContext.current
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Button(
                onClick = {
                    mediaPlayer?.release()
                    try {
                        mediaPlayer = MediaPlayer.create(context, R.raw.emergency_stop)
                        mediaPlayer?.start()
                    } catch (e: Exception) {
                        Toast.makeText(context, "Error playing sound", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
            ) {
                Text(
                    text = "EMERGENCY STOP",
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = { navController.navigate(Screen.Topics.route) },
                modifier = Modifier
                    .fillMaxWidth()
                    .semantics { contentDescription = "Navigate to Topics" }
            ) {
                Text(text = "Topics")
            }
        }
    }
    ScreenContentWithFooter(navController = navController) {}
}

@Composable
fun TopicsScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val topics = listOf(
        "General Safety Orientation",
        "PPE",
        "Fall Protection",
        "Scaffolding Safety",
        "Ladder Safety",
        "Trenching/Excavation",
        "General Jobsite Safety",
        "Restricted Access",
        "Environmental and Weather Conditions",
        "Fire Safety"
    )

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Select a Topic", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(topics) { index, topic ->
                    Button(
                        onClick = {
                            when (topic) {
                                "PPE" -> navController.navigate(Screen.PPE.route)
                                "Fall Protection" -> navController.navigate(Screen.FallProtection.route)
                                "Trenching/Excavation" -> navController.navigate(Screen.TrenchingExcavation.route)
                                "General Jobsite Safety" -> navController.navigate(Screen.GeneralJobsiteSafety.route)
                                "Restricted Access" -> navController.navigate(Screen.RestrictedAccess.route)
                                "Environmental and Weather Conditions" -> navController.navigate(
                                    Screen.EnvironmentalConditions.route
                                )
                                "Fire Safety" -> navController.navigate(Screen.FireSafety.route)
                                else -> navController.navigate(Screen.Recommendations.createRoute(topic))
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics { contentDescription = "Navigate to $topic" }
                    ) {
                        Text(text = topic)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(text = "Back", style = MaterialTheme.typography.bodyLarge, color = Color.White)
            }
        }
    }
}

@Composable
fun PPESubtopicsScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val ppeSubtopics = listOf(
        "General PPE Requirements",
        "Head Protection",
        "Eye and Face Protection",
        "Foot Protection",
        "High-Visibility Clothing",
        "Hand Protection",
        "Hearing Protection"
    )

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Select a PPE Subtopic",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(ppeSubtopics) { index, subtopic ->
                    Button(
                        onClick = {
                            navController.navigate(
                                Screen.Recommendations.createRoute(subtopic)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics { contentDescription = "Navigate to $subtopic" }
                    ) {
                        Text(text = subtopic)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun FallProtectionSubtopicsScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val fallProtectionSubtopics = listOf(
        "Harness and Lifeline",
        "Fall Protection Requirements",
        "Inspection and Compliance"
    )

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Select a Fall Protection Subtopic",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(fallProtectionSubtopics) { index, subtopic ->
                    Button(
                        onClick = {
                            navController.navigate(
                                Screen.Recommendations.createRoute(subtopic)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics { contentDescription = "Navigate to $subtopic" }
                    ) {
                        Text(text = subtopic)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun TrenchingExcavationScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val recommendations = listOf(
        "Get out of the ditch/hole.",
        "The excavation is over 5 ft. deep get out, it needs to be sloped or you need a trench box.",
        "You need a ladder in the excavation."
    )
    val context = LocalContext.current

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Recommendations for Trenching/Excavation",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(recommendations) { index, recommendation ->
                    Button(
                        onClick = { playSpanishAudio(recommendation, context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics {
                                contentDescription = "Speak recommendation: $recommendation"
                            }
                    ) {
                        Text(text = recommendation)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun GeneralJobsiteSafetyScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val subTopics = listOf(
        "Immediate Safety Concerns",
        "Equipment Safety",
        "Tool Safety",
        "Site Maintenance and Cleanliness",
        "Specific Safety Procedures",
        "Material Storage"
    )

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "General Jobsite Safety",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(subTopics) { index, subTopic ->
                    Button(
                        onClick = {
                            navController.navigate(
                                Screen.Recommendations.createRoute(subTopic)
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics { contentDescription = "Navigate to $subTopic" }
                    ) {
                        Text(text = subTopic)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun RestrictedAccessScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val recommendations = listOf(
        "The barricade needs a tag, which should include company name, contact person, and phone number.",
        "Only the electricians can access this room.",
        "Only the framers and roofers can go on the roof.",
        "This is a confined space; you need a permit and training."
    )
    val context = LocalContext.current

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Restricted Access", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(recommendations) { index, recommendation ->
                    Button(
                        onClick = { playSpanishAudio(recommendation, context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics {
                                contentDescription = "Speak recommendation: $recommendation"
                            }
                    ) {
                        Text(text = recommendation)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun EnvironmentalConditionsScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val recommendations = listOf(
        "No work allowed if it’s lightning.",
        "No work due to rain.",
        "Do you have water? Drink it frequently.",
        "Do not touch or move the heater, only authorized personnel can do it.",
        "No scaffold work or work on roofs due to high winds.",
        "Take frequent breaks in the shade during this high heat.",
        "There is not enough light in the area to do work, get additional lights."
    )
    val context = LocalContext.current

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Environmental and Weather Conditions",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(recommendations) { index, recommendation ->
                    Button(
                        onClick = { playSpanishAudio(recommendation, context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics {
                                contentDescription = "Speak recommendation: $recommendation"
                            }
                    ) {
                        Text(text = recommendation)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun FireSafetyScreen(navController: NavController, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val recommendations = listOf(
        "No fires or burning are allowed.",
        "If you are welding, burning, or using an open flame, you need a hot work permit and fire extinguisher."
    )
    val context = LocalContext.current

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = "Fire Safety", style = MaterialTheme.typography.headlineMedium)
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                itemsIndexed(recommendations) { index, recommendation ->
                    Button(
                        onClick = { playSpanishAudio(recommendation, context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp)
                            .semantics {
                                contentDescription = "Speak recommendation: $recommendation"
                            }
                    ) {
                        Text(text = recommendation)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .padding(8.dp)
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(
                    text = "Back",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun RecommendationsScreen(navController: NavController, topic: String, playSpanishAudio: (String, android.content.Context) -> Unit) {
    val recommendationsMap = mapOf(
        "General Safety Orientation" to listOf(
            "Have you been through orientation?",
            "Don’t miss any safety meetings.",
            "Please read our safety violation fines.",
            "Who do you work for?",
            "Who is in charge/Who is the boss/Who do you report to?"
        ),
        "PPE" to listOf(
            "General PPE Requirements",
            "Head Protection",
            "Eye and Face Protection",
            "Foot Protection",
            "High-Visibility Clothing",
            "Hand Protection",
            "Hearing Protection"
        ),
        "General PPE Requirements" to listOf(
            "PPE is required at all times.",
            "We will fine you if you don’t wear your PPE.",
            "Please use proper PPE."
        ),
        "Head Protection" to listOf(
            "Put on your hard hat.",
            "Where is your hard hat?",
            "You cannot wear a baseball cap or sweatshirt hood under your hard hat.",
            "The brim of your hard hat needs to be forward."
        ),
        "Eye and Face Protection" to listOf(
            "Face shield is required for this task.",
            "Put on your safety glasses.",
            "Where are your safety glasses?",
            "You cannot wear sunglasses in the building.",
            "Your safety glasses do not meet OSHA or ANSI requirements."
        ),
        "Foot Protection" to listOf(
            "Put on your work boots.",
            "You are working in concrete; put the proper boots on."
        ),
        "High-Visibility Clothing" to listOf(
            "Put on your reflective vest or high visibility clothing.",
            "Where is your reflective vest or high visibility clothing?",
            "You need a high visibility vest or clothing if you are working in or near vehicle traffic.",
            "Uncover your high visibility shirt."
        ),
        "Hand Protection" to listOf(
            "Put on your gloves.",
            "Where are your gloves?",
            "Those are the wrong gloves for the task."
        ),
        "Hearing Protection" to listOf(
            "Wear your ear protection.",
            "Where is your ear protection?"
        ),
        "Fall Protection" to listOf(
            "Harness and Lifeline",
            "Fall Protection Requirements",
            "Inspection and Compliance"
        ),
        "Harness and Lifeline" to listOf(
            "Your harness is not being worn correctly.",
            "The leg straps of your harness must be connected and secured.",
            "Take the slack out of your rope slide up your rope grab.",
            "Adjust the lifeline.",
            "Adjust the slack on your lifeline or relocate the anchor point; you are exposed to a swing hazard.",
            "Your D ring needs to be between your shoulder blades.",
            "The energy absorber’s cover is missing."
        ),
        "Fall Protection Requirements" to listOf(
            "Fall protection is required above six feet.",
            "You need fall protection when working at or above 6 feet No exceptions.",
            "You need guard rails around this floor hole and wall opening.",
            "You cannot walk the top plate of walls."
        ),
        "Inspection and Compliance" to listOf(
            "Have you inspected your safety harness, self retractable lifeline SRL or Yoyo, and/or lanyard, and other fall protection equipment being used?",
            "How many nails did you use to install the hinge anchor?",
            "Did you follow the manufacturer's instructions?",
            "Have you inspected your personal fall arrest system?"
        ),
        "Scaffolding Safety" to listOf(
            "You need guard rails on your scaffolding.",
            "You can’t climb the scaffolding; you need a ladder.",
            "The scaffolding must be inspected and tagged before you can use it.",
            "Your scaffolding is not safe, stop work and correct.",
            "You have damaged scaffold components.",
            "The scaffold boards need to meet OSHA requirements.",
            "The scaffold needs to be fully planked with no openings.",
            "You need a top and mid rail. The crossbars can be used for one of them.",
            "On mobile scaffold lock the wheels, you cannot move the scaffold with somebody on it.",
            "You cannot throw materials up or down.",
            "The scaffold is missing locking pins.",
            "Scaffold components need to be from the same manufacturer.",
            "If materials are on the scaffold, it is a working scaffold and needs to comply with all scaffold and fall protection measures.",
            "Did you follow the manufacturer's instructions?"
        ),
        "Ladder Safety" to listOf(
            "Your ladder needs to extend 3 feet above your landing.",
            "Your ladder needs to be tied off at the top and bottom.",
            "The top of the straight ladder needs to be secured.",
            "Your ladder is damaged, take it off the site.",
            "You cannot throw materials up or down."
        ),
        "Trenching/Excavation" to listOf(
            "Get out of the ditch/hole.",
            "The excavation is over 5 ft. deep get out, it needs to be sloped or you need a trench box.",
            "You need a ladder in the excavation."
        ),
        "Immediate Safety Concerns" to listOf(
            "Stop! That isn't safe.",
            "Get out of the ditch/hole.",
            "Dont walk under the load of the crane.",
            "Overhead power lines Stay at least 10 feet away.",
            "Only authorized and trained workers can enter confined spaces and a permit is needed.",
            "Get down, you are working at or above 6 feet without fall protection."
        ),
        "Equipment Safety" to listOf(
            "Have you inspected the scissor lift or boom lift?",
            "Have you been trained to operate this piece of equipment?",
            "Do you have the proper rigging to move these materials with the crane?",
            "Do you have a lift plan?",
            "Did you follow the manufacturer's instructions?",
            "All mobile equipment needs working backup alarms."
        ),
        "Tool Safety" to listOf(
            "Did you follow the manufacturer's instructions?",
            "Your extension cord is damaged and needs to be taken off site.",
            "Protect that extension cord from damage.",
            "Have you inspected your hand and power tools this month?",
            "This tool is damaged. Take it off site."
        ),
        "Site Maintenance and Cleanliness" to listOf(
            "Please clean your space.",
            "We need to throw away the trash into provided containers.",
            "Please pick up your trash and dispose of it in the provided containers.",
            "Ensure your boots are clean of mud prior to entering the building.",
            "Do not dump paint or other chemicals in the storm drain."
        ),
        "Specific Safety Procedures" to listOf(
            "Water needs to be used while cutting and/or grinding concrete or masonry to reduce silica dust.",
            "You need to use dust control attachments designed for the tool.",
            "Use Hepa Vacuum system when sanding drywall to control the silica dust."
        ),
        "Material Storage" to listOf(
            "Materials are leaning and will fall over, stack them properly or move them.",
            "Materials and tools are blocking areas where work needs to be completed, please move them ASAP."
        )
    )

    val recommendations = recommendationsMap[topic] ?: emptyList()
    val context = LocalContext.current

    ScreenContentWithHeader(navController = navController) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 20.dp),
            verticalArrangement = Arrangement.Top,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Recommendations for $topic",
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(bottom = 16.dp)
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                itemsIndexed(recommendations) { index, recommendation ->
                    Button(
                        onClick = { playSpanishAudio(recommendation, context) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .height(56.dp)
                            .semantics { contentDescription = "Speak recommendation: $recommendation" },
                        shape = MaterialTheme.shapes.medium
                    ) {
                        Text(text = recommendation, style = MaterialTheme.typography.bodyLarge)
                    }
                }
            }

            Button(
                onClick = { navController.popBackStack() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp)
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Blue)
            ) {
                Text(text = "Back", style = MaterialTheme.typography.bodyLarge, color = Color.White)
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    PROJECTTheme {
        val navController = rememberNavController()
        HomeScreen(navController) { _, _ -> }
    }
}

@Preview(showBackground = true)
@Composable
fun TopicsScreenPreview() {
    PROJECTTheme {
        val navController = rememberNavController()
        TopicsScreen(navController) { _, _ -> }
    }
}

@Preview(showBackground = true)
@Composable
fun RecommendationsScreenPreview() {
    PROJECTTheme {
        val navController = rememberNavController()
        RecommendationsScreen(navController, "General Safety Orientation") { _, _ -> }
    }
}

@Preview(showBackground = true)
@Composable
fun ScaffoldingSafetyPreview() {
    PROJECTTheme {
        val navController = rememberNavController()
        RecommendationsScreen(navController, "Scaffolding Safety") { _, _ -> }
    }
}